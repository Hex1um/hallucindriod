/* ============ Hallucindriod · 幻卓 · LLM 幻觉层（浏览器直连 · 多源竞速 + fallback） ============
 * 关键点：
 *  - 纯静态站没有后端，直接 fetch 免费 LLM 公共端点（必须支持 CORS）。
 *  - 主源 Pollinations（text.pollinations.ai/openai，CORS:*，免 Key）：openai-fast / openai 竞速。
 *    ※ Pollinations 对已登记来源（如生产域名 hex1um.github.io）CORS 放行；
 *      对 localhost 等未知来源会要求 Turnstile token，此时会自动走下面的备用源。
 *  - 备用源（换服务/换路径）：Pollinations 文本端点、AI Horde（众包 GPU，免 key，CORS:*）。
 *  - 配置了自定义 OpenAI 兼容端点时优先走自定义，失败再回退内置源。
 *  - 只有所有源都失败才返回 null → 调用方用本地词库兜底。
 *  - 置信度 confidence ∈ [0,1] 控制「现实 ↔ 幻觉」。
 */
(function(){
  const D=window.OS_DATA;

  // 竞速窗口：谁先在窗口内返回有效 JSON 就用谁；超时即切换下一个源
  // 本地开发：Pollinations 对 localhost 会触发人机验证，可用 dev-proxy.mjs 转发
  const IS_LOCAL=(typeof location!=='undefined')&&/^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname||'');
  const LLM_BASE=IS_LOCAL?'http://localhost:8787/api':'https://text.pollinations.ai';
  const RACE_FAST=9000;    // 阶段一（Pollinations 双模型）
  const RACE_BACKUP=18000; // 阶段二（文本端点 / AI Horde 轮询）
  const RACE_CUSTOM=12000; // 自定义端点

  // 每个应用的 JSON 结构提示
  const SCHEMA={
    evolve: n=>`你在续写一座虚构城市的编年史。当前世界：${n}。请写出它的"下一天"：只输出纯JSON：{"events":["今天新发生的三件事，每件18字内，要有画面感"],"echo":["昨天某件事今天应验/发酵的表现，一句15字内"]}。要求：事件要具体、彼此有因果感；不要照抄输入里的原句；echo 必须能从输入的事件里找到源头。`,
    weather: n=>`为天气App编内容。格式：{"city":"城市名","weather":"天气现象","temp":数字,"tip":"一句天气提示，20字内"}。主题：${n}`,
    notes:   n=>`编一条中文便签。格式：{"text":"便签正文，35字内","mood":"一个emoji","sign":"署名地点"}。主题：${n}`,
    store:   n=>`编3个中文App。格式：{"apps":[{"name":"App名","desc":"一句介绍，20字内","emoji":"一个emoji"}]}。主题：${n}`,
    browser: n=>`用户想打开「${n}」。先判断它是什么网站（社交/视频/购物/资讯/工具/企业/政府/论坛/博客等），据此设计一个符合该定位的中文网页首页。
只输出一个纯JSON对象，不要markdown代码块，不要解释。
格式示例（**下面只是格式示意，你必须根据「${n}」写出全新的真实内容，严禁照抄示例里的任何文字**）：
{"siteName":"荒野气象台","type":"news","tagline":"每天一点天气","heroTitle":"今天，风从西边来","heroSub":"城郊的风力比昨天大了两级，出门记得压住帽子。","cta":"查看预报","aboutTitle":"关于我们","about":"三个气象爱好者在楼顶搭了一台旧仪器，后来它一直没坏。","features":[{"icon":"🌤","title":"实时云图","desc":"每十分钟更新一次，误差不大"},{"icon":"📮","title":"订阅提醒","desc":"变天前一小时发消息给你"},{"icon":"🗂","title":"历史查询","desc":"翻得到过去三年的记录"}],"stats":[{"num":"12万","label":"订阅用户"},{"num":"4.8","label":"用户评分"},{"num":"96%","label":"预报准确率"}]}
要求：
1) type 只能是 social/video/shop/news/tool/official/forum/wiki/blog 之一；
2) siteName 是真正的站名，不要写"品牌名"这种占位词；
3) tagline/heroTitle/heroSub/cta/about/features/stats 全部针对「${n}」编写，彼此呼应；
4) 禁止出现"X字内""2-6字""示例""占位"这类词。`,
    websearch:n=>`模拟搜索引擎对「${n}」的搜索结果。只输出纯JSON：{"results":[{"title":"结果标题，16字内","site":"域名如 zhihu.com","snippet":"摘要，30字内"}]}。生成3条可信的中文结果，来自不同知名网站。`,
    messages:n=>`为一个手机社交App生成消息页。格式：{"me":"我的昵称","status":"在线状态","subs":[{"name":"订阅号名","avatar":"一个emoji"}],"chats":[{"name":"昵称","preview":"最新动态，24字内","time":"刚刚","unread":数字0-99,"muted":false,"avatar":"一个emoji","badge":"Lv8","fire":数字0-99}]}。生成4个订阅号、6条消息，主题：${n}`,
    album:   n=>`编4张照片标题。格式：{"photos":[{"title":"照片标题，8字内","emoji":"一个emoji"}]}。主题：${n}`,
    fish:    n=>`编一个摸鱼检测结果。格式：{"verdict":"一句摸鱼结论，20字内","advice":"一句建议，15字内"}。主题：${n}`,
    map:     n=>`编一个城市地图。格式：{"city":"城市名","marks":["地标1","地标2","地标3","地标4"]}。主题：${n}`,
    music:   n=>`编3首中文歌。格式：{"songs":[{"title":"歌名","artist":"歌手名"}]}。主题：${n}`,
    health:  n=>`编一段健康数据点评。格式：{"comment":"一句健康点评，25字内"}。主题：${n}`,
    settings:n=>`为一台手机生成系统状态。格式：{"device":"设备型号名，如 幻卓 Pro","comment":"一句系统状态说明，20字内"}。主题：${n}`,
    clock:   n=>`编一句时钟寄语。格式：{"comment":"一句话，20字内"}。主题：${n}`,
    camera:  n=>`为一次拍照生成内容。格式：{"scene":"一个emoji表示拍摄场景","caption":"照片标题，10字内","tip":"一句拍摄提示，16字内"}。主题：${n}`,
    game:    n=>`编一句游戏口号。格式：{"comment":"一句话，20字内"}。主题：${n}`,
    phone:   n=>`为一次通话生成内容。格式：{"contact":"通话对象称呼","line":"对方在电话里说的一句话，20字内"}。主题：${n}`,
    delivery:n=>`为一个本地生活App生成首页。格式：{"city":"城市","rank":{"title":"榜单名如 吃喝玩乐指南","item":"榜单项标题18字内","tag":"热评榜第4名","dist":"2.9km"},"free":"免费试活动文案16字内","feed":[{"title":"图文标题20字内","author":"用户昵称","level":"Lv数字","likes":数字,"emoji":"一个emoji"}]}。生成4条图文，主题：${n}`,
    video:   n=>`为一个短视频App生成内容流。只输出纯JSON，格式示例（示例文字必须全部替换成你自己的内容）：
{"videos":[{"title":"凌晨三点的城市","up":"@夜行记录","desc":"没什么事，就是想走走","style":"night","music":"晚风","likes":12800,"comments":[{"user":"阿泽","text":"这个点还在外面的都是同类","likes":847,"loc":"广东","reply":"作者：谢谢"}]}]}
规则：
1) 生成 6 条，语气像真实用户拍的短视频；
2) style 只能是 night/nature/food/cat/tech/rain 之一，必须与该条视频内容相符（决定了画面风格）；
3) 每条 comments 至少 2 条，评论必须**针对这条视频的内容**（比如猫的视频评论聊猫），不要泛泛而谈；
4) 若系统提示的置信度很低，评论可以开始跑题、变得荒诞或自我矛盾——这是有意为之；
5) likes 是数字不是字符串。主题：${n}`,
    terminal:n=>`你是手机智能助手。用户指令：「${n}」。把指令解析成可执行动作，只输出纯JSON：{"reply":"对用户的自然语言回应，16字内","actions":[{"type":"动作类型","target":"目标值","label":"动作简述，8字内"}]}。可用动作：openApp(打开应用,target填应用名如 天气/相机/音乐/地图/浏览器/云讯/电话/设置/应用商店)、closeApp(关闭当前应用)、toast(显示提示,target填提示文字)、toggle(开关,target填 wifi/蓝牙/手电筒/飞行模式/勿扰)、call(拨号,target填号码或联系人)、message(给好友发消息,target填好友名,text填内容)、installApp(下载安装应用,target填应用名)、browse(打开网页,target填主题或网址)、searchApp(应用商店搜索,target填关键词)、setIdentity(修改我的名字,target填新名字)、setPersona(切换系统人格,target填 毒舌/温柔/中二/翻译腔/默认)、evolveWorld(推进世界一天)、shareApp(分享当前应用)、screenshot(假装截屏)。actions 里可带 text 字段作为动作参数。最多3个动作。`,
    friend:  n=>`为一个网名叫「${n}」的聊天好友生成人设。格式：{"avatar":"一个emoji","level":"Lv数字","bio":"个性签名，16字内","greeting":"主动打招呼的一句话，20字内"}。只输出JSON。`,
    chatreply:n=>`你在扮演一个聊天对象，和用户闲聊。上下文：${n}。规则：1)用一句自然口语回复，20字内；2)若 persona 字段描述了这个人的身份/性格，请贴合它说话；3)若 group 字段非空，说明这是群聊，语气可以更随意；4)不要复述对方的原话。只输出JSON：{"reply":"你的回复"}`,
    calculator:n=>`为AI计算器生成两句话。格式：{"sign":"AI助手签名，8字内","tip":"算错结果时的吐槽，18字内"}。主题：${n}`
  };

  function systemPrompt(conf,id){
    // 智能终端是动作规划器：要精确、听话，不受置信度的荒诞风格影响
    if(id==='terminal')return '你是「Hallucindriod」手机内置智能终端的动作规划引擎。你理解用户的中文指令，把它拆解成手机可执行的结构化动作。要求：1)严格只输出一个纯JSON对象，不要markdown代码块、不要任何解释文字或前后缀；2)reply 是对用户的简短自然回应；3)actions 是动作数组，只能使用给定的动作类型，target 用中文应用名或给定枚举值；4)不做无法执行的事情，不编造不存在的动作类型。';
    const pct=Math.round(conf*100);
    if(conf>=0.8) return '你是「Hallucindriod」的内容引擎，当前置信度 '+pct+'%。请生成【尽量贴近真实世界、合理可信】的中文内容：数据真实、符合常识、不荒诞。只输出一个纯JSON对象，不要markdown代码块，不要任何解释文字或前后缀。';
    if(conf>=0.5) return '你是「Hallucindriod」的幻觉内容引擎，当前置信度 '+pct+'%。请生成【一半真实一半荒诞、带点冷幽默】的中文创意内容。只输出一个纯JSON对象，不要markdown代码块，不要任何解释文字或前后缀。';
    if(conf>=0.2) return '你是「Hallucindriod」的创意幻觉内容引擎，当前置信度 '+pct+'%。请生成【天马行空、幽默荒诞、一本正经地虚构】的中文创意内容，比如会下代码雨的天空、会用月亮煮汤的城市。只输出一个纯JSON对象，不要markdown代码块，不要任何解释文字或前后缀。';
    return '你是「Hallucindriod」的奇想内容引擎，当前置信度 '+pct+'%。请生成【充满想象力、超现实、像童话或梦境一样】的中文内容：奇妙的地点、不可思议的天气、有趣的虚构数据。只输出一个纯JSON对象，不要markdown代码块，不要任何解释文字或前后缀。';
  }
  function temperature(conf,id){ return id==='terminal'?0.15:+(0.2+(1-conf)*0.95).toFixed(2); }
  // 世界状态前缀：13 个应用共享同一座城、同一批事件（playbook 1.1）
  function worldPrefix(){
    const D=window.OS_DATA;
    if(!D||!D.ensureWorld)return '';
    let w=null;
    try{ w=D.ensurePersona?D.ensurePersona():D.ensureWorld() }catch(e){ return '' }
    if(!w||!w.city)return '';
    let t='【世界观】你所在的城市叫「'+w.city+'」。';
    if(w.persona&&w.persona.role)t+='用户今天的身份是「'+w.persona.role+'」。';
    if(w.hotEvents&&w.hotEvents.length)t+='最近这座城里发生：'+w.hotEvents.slice(0,2).join('；')+'。';
    t+='生成内容必须与这个世界保持一致：提到的地点只能是「'+w.city+'」及周边，可自然呼应上面的事件（不要照抄原句）。\n';
    return t;
  }
  // 系统人格：让整机文案有统一语气（playbook ②）
  function personaPrefix(){
    const D=window.OS_DATA;
    const cfg=(D&&D.CONFIG)||{};
    const key=cfg.persona||'none';
    const P=D&&D.PERSONAS&&D.PERSONAS[key];
    if(!P||key==='none')return '';
    return '【语气】你要用「'+P.name+'」的口吻：'+P.tone+'。文案要带这个语气，但不要因此写错数据。\n';
  }

  function buildUserPrompt(id,name){
    const skipWorld=(id==='terminal'||id==='friend'||id==='chatreply');
    const pre=skipWorld?personaPrefix():(worldPrefix()+personaPrefix());
    if(id==='__generic__'||!SCHEMA[id]) return pre+'用户想要一个叫「'+name+'」的手机App。只输出纯JSON：{"tagline":"贴合这个应用的宣传语，20字内","features":["贴合该应用的具体能力","另一项具体能力","第三项具体能力"]}。要求：features 必须是和「'+name+'」相关的具体能力短语，禁止出现"功能1""功能2"这类占位文字。';
    return pre+SCHEMA[id](name);
  }
  // 容错修复：去掉尾随逗号、补齐被截断的引号与括号（免费源经常在末尾断掉）
  function repairJSON(src){
    const s=String(src);
    // 记录所有可能的安全切点（字符串外的 , { [）
    const cuts=[];
    let inStr=false,esc=false;
    for(let i=0;i<s.length;i++){
      const ch=s[i];
      if(inStr){
        if(esc)esc=false;
        else if(ch==='\\')esc=true;
        else if(ch==='"')inStr=false;
        continue;
      }
      if(ch==='"'){inStr=true;continue}
      if(ch===','||ch==='{'||ch==='[')cuts.push(i);
    }
    cuts.push(s.length);
    // 从最长的可解析前缀往前退
    for(let k=cuts.length-1;k>=0;k--){
      let t=s.slice(0,cuts[k]).replace(/[,\s]+$/,'');
      if(!t)continue;
      let ob=0,abr=0,st=false,es=false,bad=false;
      for(let i=0;i<t.length;i++){
        const ch=t[i];
        if(st){
          if(es)es=false;
          else if(ch==='\\')es=true;
          else if(ch==='"')st=false;
          continue;
        }
        if(ch==='"'){st=true}
        else if(ch==='{')ob++;
        else if(ch==='}'){ob--;if(ob<0){bad=true;break}}
        else if(ch==='[')abr++;
        else if(ch===']'){abr--;if(abr<0){bad=true;break}}
      }
      if(bad||st||ob<0||abr<0)continue;
      let fixed=t;
      while(abr-->0)fixed+=']';
      while(ob-->0)fixed+='}';
      fixed=fixed.replace(/,\s*([}\]])/g,'$1');
      try{ JSON.parse(fixed); return fixed }catch(e){ continue }
    }
    return null;
  }

  function extractJSON(text){
    if(!text)return null;
    let s=String(text).trim();
    const fence=s.match(/```(?:json)?\s*([\s\S]*?)```/i);
    if(fence)s=fence[1].trim();
    const a=s.indexOf('{');
    if(a<0)return null;
    let body=s.slice(a);
    // 先按最后一个 } 截取（有完整结尾时最快）
    const b=body.lastIndexOf('}');
    if(b>0){
      try{ return JSON.parse(body.slice(0,b+1)) }catch(e){}
    }
    // 失败则容错修复后再试
    const fixed=repairJSON(body);
    if(fixed){ try{ return JSON.parse(fixed) }catch(e){} }
    return null;
  }

  // ---------- 各数据源实现：统一签名 (ctx, signal) => Promise<data|null> ----------
  function messagesOf(ctx){ return [{role:'system',content:ctx.sys},{role:'user',content:ctx.user}]; }

  // Pollinations OpenAI 兼容端点（CORS:*，免 Key）
  async function plChat(model,ctx,signal){
    const r=await fetch(LLM_BASE+'/openai',{
      method:'POST',signal,headers:{'Content-Type':'application/json'},
      body:JSON.stringify({model,messages:messagesOf(ctx),temperature:ctx.temp,max_tokens:ctx.maxTokens||400})
    });
    if(!r.ok)return null;
    const j=await r.json();
    const c=j&&j.choices&&j.choices[0]&&j.choices[0].message&&j.choices[0].message.content;
    return extractJSON(c);
  }
  // Pollinations 纯文本端点（另一条路径，兜底）
  async function plText(ctx,signal){
    const prompt=ctx.sys+'\n\n'+ctx.user;
    const r=await fetch(LLM_BASE+'/'+encodeURIComponent(prompt)+'?model=openai-fast',{signal});
    if(!r.ok)return null;
    return extractJSON(await r.text());
  }
  // AI Horde：众包 GPU 网络，免 key（anonymous key）+ CORS:*，真正的独立备用源
  // 流程：提交异步任务 → 轮询状态直到出文本（最多约 16s）
  async function hordeChat(ctx,signal){
    const prompt=ctx.sys+'\n\n'+ctx.user+'\n\n只输出一个纯JSON对象。';
    const sub=await fetch('https://aihorde.net/api/v2/generate/text/async',{
      method:'POST',signal,
      headers:{'Content-Type':'application/json','apikey':'0000000000'},
      body:JSON.stringify({prompt,max_tokens:300})
    });
    if(!sub.ok)return null;
    const job=await sub.json();
    const id=job&&job.id;
    if(!id)return null;
    const deadline=Date.now()+16000;
    while(Date.now()<deadline){
      await new Promise(r=>setTimeout(r,1500));
      if(signal&&signal.aborted)return null;
      const s=await fetch('https://aihorde.net/api/v2/generate/text/status/'+id,{signal});
      if(!s.ok)return null;
      const st=await s.json();
      if(st.done&&st.generations&&st.generations.length){
        return extractJSON(st.generations[0].text);
      }
    }
    return null;
  }
  // 用户自定义 OpenAI 兼容端点
  async function customChat(ctx,signal){
    const cfg=D.CONFIG;
    const headers={'Content-Type':'application/json'};
    if(cfg.apiKey)headers['Authorization']='Bearer '+cfg.apiKey;
    const r=await fetch(cfg.apiBase.replace(/\/$/,'')+'/chat/completions',{
      method:'POST',signal,headers,
      body:JSON.stringify({model:cfg.model||'gpt-4o-mini',messages:messagesOf(ctx),temperature:ctx.temp,max_tokens:ctx.maxTokens||400})
    });
    if(!r.ok)return null;
    const j=await r.json();
    const c=j&&j.choices&&j.choices[0]&&j.choices[0].message&&j.choices[0].message.content;
    return extractJSON(c);
  }

  // 源清单（label 用于状态行展示真实使用的源）
  const SOURCES={
    plFast:  {label:'Pollinations · 极速', call:(ctx,s)=>plChat('openai-fast',ctx,s)},
    plStd:   {label:'Pollinations · 标准', call:(ctx,s)=>plChat('openai',ctx,s)},
    plText:  {label:'Pollinations · 文本', call:(ctx,s)=>plText(ctx,s)},
    horde:   {label:'AI Horde · 众包',    call:(ctx,s)=>hordeChat(ctx,s)}
  };

  // 竞速：窗口内第一个返回有效 JSON 者胜出；全部快速失败则提前结束
  function race(list,ctx,winMs){
    return new Promise(resolve=>{
      if(!list.length){resolve(null);return}
      let done=false,settled=0;
      const ctrls=[],timers=[];
      const finish=(res,winIdx)=>{
        if(done)return;done=true;
        timers.forEach(clearTimeout);
        ctrls.forEach((c,i)=>{if(i!==winIdx){try{c.abort()}catch(e){}}});
        resolve(res);
      };
      list.forEach((src,i)=>{
        const ctrl=new AbortController();ctrls[i]=ctrl;
        timers.push(setTimeout(()=>{try{ctrl.abort()}catch(e){}},winMs+4000)); // 单源硬超时
        Promise.resolve()
          .then(()=>src.call(ctx,ctrl.signal))
          .then(data=>{
            if(done)return;
            if(data)finish({data,source:src.label},i);
            else if(++settled===list.length)finish(null,-1);
          })
          .catch(()=>{if(!done&&++settled===list.length)finish(null,-1)});
      });
      timers.push(setTimeout(()=>finish(null,-1),winMs));
    });
  }

  // 主入口：Promise<data|null>，并把实际使用的源写到 window.__LLM_SOURCE
  async function fetchHallucination(id,name){
    const cfg=D.CONFIG;
    const conf=Math.max(0,Math.min(1,Number(cfg.confidence)));
    const isBrowser=id==='browser';
    const isTerminal=id==='terminal';
    // browser 生成完整官网 JSON 偏慢，但已精简字段；给 18s 窗口，超时再走备用源
    const isWeb=(isBrowser||id==='websearch'||id==='evolve');
    const heavy=isWeb?650:((id==='delivery'||id==='video'||id==='messages')?650:400);
    const ctx={sys:systemPrompt(conf,id),user:buildUserPrompt(id,name),temp:temperature(conf,id),maxTokens:heavy};
    // browser 要生成完整官网 JSON（约 15s），给足竞速窗口；
    // terminal 只是短 JSON 意图解析，给短窗口保证快速响应；其他应用保持默认
    const isChat=(id==='friend'||id==='chatreply');
    const fastWin=isWeb?16000:((isTerminal||isChat)?6500:RACE_FAST);
    const backupWin=isWeb?20000:((isTerminal||isChat)?7000:RACE_BACKUP);
    window.__LLM_SOURCE='';
    window.__LLM_DIAG=[];

    // 1) 自定义端点优先
    if(cfg.apiBase&&cfg.apiBase.trim()){
      const r=await race([{label:'自定义 API',call:customChat}],ctx,RACE_CUSTOM);
      if(r){window.__LLM_SOURCE=r.source;return r.data}
      window.__LLM_DIAG.push('自定义端点不可用');
    }

    // 2) 阶段一：Pollinations 双模型竞速（快的胜出，慢的被 abort）
    let r=await race([SOURCES.plFast,SOURCES.plStd],ctx,fastWin);
    if(r){window.__LLM_SOURCE=r.source;return r.data}
    window.__LLM_DIAG.push('Pollinations 超时/失败');

    // 3) 阶段二：换源——文本端点（换路径）+ AI Horde（换服务），给足轮询时间
    r=await race([SOURCES.plText,SOURCES.horde],ctx,backupWin);
    if(r){window.__LLM_SOURCE=r.source;return r.data}
    window.__LLM_DIAG.push('备用源均不可用');

    return null;
  }

  window.LLM={fetchHallucination,systemPrompt,temperature,
    // 供测试/调试查看实际提示词（不参与运行时逻辑）
    buildUserPrompt, worldPrefix, personaPrefix};
})();
